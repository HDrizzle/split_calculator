This is a Sailboat Simulator multiplayer game written in Python 3 by Hadrian Ward <hadrian.f.ward@gmail.com>.
NOTE: THIS IS ASSUMING THE READER KNOWS HOW TO USE Python 3 AND INSTALL MODULES WITH Pip 3.
This program is intended to run on any computer with Python 3,
however it may be hard to get all of the dependencies working and from my experience it is esier to run on a PC.
A list of dependencies is at the bottom of docs/documentation.html.
For the GUI (graphical User Interface) run main.py in the sailboat_simulator_vXXXX.XX.XX folder, more documentation is in docs/documentation.html.
NOTE: some simulations are not up to date and may not work, one that I know works is "demo_sim".
To start a server (No GUI) run simulator.py.
When running main.py or simulator.py for the first time it will ask for a directory for it to use to load simulations, settings, etc., enter the absolute path for sailboat_simulator_data.
